# Amazon-Clone
This is a clone of Amazon website. I used React.js and Tailwind on the UI and Fake Store API for the products data.

My motivation building this application was to build a simple e-commerce application with features like adding, removing products to/from basket and authenticating user with Google account.

I will with high possibility add more features in the upcoming days.

💻 Tech stack:
React.js,
Tailwind CSS,
Redux Toolkit,
Firebase Authentication,
